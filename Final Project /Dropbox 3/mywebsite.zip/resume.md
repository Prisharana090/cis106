![resume](resumepfp.jpg)
# Pisha rana 
>
>Address:avenue, apt #                            
>Phone: ###-###-####            
>Email:prisharana090@gmail.com
___________________________________________________________________________ 

##  EDUCATION
> Passaic community college  Passaic, Nj 
Bachelor of science in computer science

>Passaic Academy for science and Engineering Passaic, NJ 
> High school graduated with seal of biliteracy  GED 
> Drawing club 
> India club 
>Hiking club 
> Journalism club
> Member of Global citizen club 

___________________________________________________________________________
## WORK EXPERIENCE                                                                                                                                                                                                           
> - Dunkin donuts, Wallington, NJ , september 2023 
Crew member
 > - Proven great communication skills when taking care of customers and leading a team.
>- Successfully interacted with clients to meet their needs and address queries. 
>- worked together with teammates to fulfill orders effectively during rush hours. 
>- seeking and expression of positive and negative feedback to improve work efficiency and maintain standards. 
> - Best Pharmacy, Passaic, NJ , July 2023 
	staff member 
> - communication skills in dealing with customers and coworkers, always using appropriate and clear language. 
> - Coordinate and send messages about when to pick up prescriptions, insurance inquiries, and medication instructions.
> - Worked with pharmacy team members to facilitate prescription orders, resolve any problems in a timely manner and efficiently.  
> - Acquired proficiency of writing feedback reports, which contained useful and constructive content to improve processes and boost customer satisfaction. 
__________________________________________________________________________                                                                                                             
## SKILLS
> - Microsoft office 
> - Writing and communication skills 
> - Adaptability and willingness to learn new skills and technology.
> - Python 
>- Leadership 
> - Teamwork 
> - Digital art 
> - Language = Fluent in English, Gujarati, Hindi 
___________________________________________________________________________

                                                                   
## PROJECTS/RESEARCH 
> - Projects:Building a calculator using Python 
> - Research: Machine learning, AI 
> - robot 
